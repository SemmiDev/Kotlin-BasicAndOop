fun main() {
    var person = hashMapOf<Int,String>(1 to "Sammi Aldhiyanto", 2 to "Aditya Andika Putra")
    person.put(3,"Ayatullah Ramadhan Jacoeb") // pakai put tidak pakai to lagi

    // sesuai key
    println(person.get(3))
    println(person[3])

    // implementasi arrayOf dan ListOf

    var person2 = arrayOf("adit","dandi")
    println(person2[0])

    // implementasi listOf
    var person3 = listOf<String>("sam","rauf")
    for(peron3Show in person3){
        println(peron3Show)
    }
    // jika kita menggunakan listOf kita tidak bisa merubah isi didalamnya, kalau pengen dirubah ubah tipe listOf jadi muutableListOF
    person3 = mutableListOf("sam","hello","andwhen")
    person3[0] == "andwhen"

    println(person3[0])


}