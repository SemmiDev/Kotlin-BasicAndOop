package Advanced

fun hitung(a: Int, b: Int): Int{
    return a + b
}

fun hitung(a: Double, b: Double): Double{
    return  a + b
}

fun hitung(a: Int, b: Int, c: Int): Int{
    return a + b + c
}

fun hitung(a: Char, b: Char): String{
    return  "your character is $a & $b"
}


fun main() {
    var a = hitung(1,2)
    var b = hitung(1.2,3.4)
    var c = hitung(1,2,3)
    var d = hitung('a','b')

    println(a)
    println(b)
    println(c)
    println(d)
}