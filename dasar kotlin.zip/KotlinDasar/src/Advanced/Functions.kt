package Advanced

import java.lang.NumberFormatException
import java.text.NumberFormat

// membuat functions
// :Double sebelum kurung kurawal digunakan untuk return
fun add(nilai1: Double, nilai2: Double): Double {
    var a = nilai1 + nilai2
    return a
}

// untuk satu nilai
    // untuk memberikan nilai default kita bisa langsung menginisialisasi parameter yg dibuthkan tersebut
fun NameShow(names:String = "null"): Unit{
    println("your name is $names")
}

// function tanpa parameter / void, boleh mnggunakan unit atau tidak
fun helloWorld(){
    println("HEllo WOrld")
}


fun main() {
    // pemanggilan kita tampung dulu dalam sebuah var

    print("Masukkan angka 1 : ")
    var input = readLine()!!.toDouble()
    print("Masukkan angka 2 : ")

    var input2 = readLine()!!.toDouble()

    var panggilFunc = add(input,input2)
    println("hasil dari ${input} + ${input2} : " + panggilFunc)



    print("input you name : ")
    var input3 = readLine()
    // panggil method unit
    if (input3 != null) {
        NameShow(input3)
    }


helloWorld()

}