package Advanced

var namaLengkap = "SAMMI ALDHIYANTO" // variable global

fun hello(){
    println("nama lengkap saya adalah : $namaLengkap")
}

fun main() {
    var nama = "Sam" // variable local, hanya dapat di akses oleh method itu sendiri
    println("nama saya adalah : $nama")
    println("nama lengkap saya adalah : $namaLengkap")

    hello()
}