fun main() {
    val name = hashMapOf<Int,String>()
    name.put(1,"Sammi")
    name.put(2,"Dev")
    name.put(2,"Sammi")
    // akan replace yg sudah ada
    for(i in name.keys){
        println(name[i])
    }


    name.putIfAbsent(3,"Sammi ALdhiyanto")

    println(name.get(3))
    name.replace(2,"Sammmi")

    

}