fun main() {
    // mutable bisa di rubah nilainya
    // tanpa mutable tidak bisa

    var angka1 = setOf<String>("sam","dev")
    for (angka1Show in angka1){
        println(angka1Show)
    }

    var angka2 = mutableListOf<String>("sam","Dev")
    angka2.add(0,"hello")
    for (angka2Show in angka2){
        println(angka2Show)
    }
}