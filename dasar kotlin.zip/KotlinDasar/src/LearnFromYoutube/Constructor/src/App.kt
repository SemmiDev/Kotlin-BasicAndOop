import com.constructor.Person
import com.constructor.SignIn

fun exit(){
    System.exit(0)
}

fun main() {

    println("PLEASE SIGN UP")

        print("input your username : ")
        var inputUsername = readLine()
        print("input you password  : ")
        var inputPassword = readLine()

        if(inputUsername != null && inputPassword != null){
            var person = Person(inputUsername,inputPassword)
        }

        println("do you next login? or Exit? (signIn | exit)")
        var quest = readLine()
        when(quest){
            "signIn" -> SignIn().signIn()
            "exit"   -> exit()
            else     -> exit()
        }


}