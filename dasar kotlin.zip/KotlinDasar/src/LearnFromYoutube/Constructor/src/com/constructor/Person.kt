package com.constructor

var nameBase = arrayOf<String>("sam")
var passBase = arrayOf<String>("sam")

class Person(var username: String, var password: String){
    fun addToBase(){
        var index = 0
        nameBase[index] = username
        passBase[index] = password
        index++
    }
}

class SignIn{
    fun signIn(){
        print("input your username : ")
        var usernameLogin = readLine()
        print("input your password : ")
        var passwordLogin = readLine()


        if (usernameLogin != null && passwordLogin != null) {
            if(usernameLogin.equals(nameBase[0]) && (passwordLogin.equals(0)) ){
                println("success")
            }else{
                println("not success")
            }
        }else{
            println("failed to login")
           System.exit(0)
        }


    }
}