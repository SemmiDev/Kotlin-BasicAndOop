@file:JvmName("myKotlinAddFUnctions")
package KotlinCode

import JavaCode.JavaApp
import java.lang.Math.pow
import java.lang.Math.sqrt

fun main() {
    // access file form java
    var getArea = JavaApp.getArea(5,3);
    println("get area : " + getArea)

    // access default parameters
    var luasSegitiga1 = luasSegitiga(2)
    println("luas segitiga " + luasSegitiga1)

    luasLingkaran(3.3)
}

// access from java file
fun add(a: Int, b: Int): Int{
    return a + b
}

// default parameter value, untuk bisa diterapkan di java gunakan keyword @jvmoverloads
@JvmOverloads
fun luasSegitiga(alas: Int, tinggi: Int = 12): Int{
    return (alas + tinggi) / 2
}

fun luasLingkaran(r: Double){
    var a = Math.PI
    var result = a * sqrt(r)
    println(result)

}