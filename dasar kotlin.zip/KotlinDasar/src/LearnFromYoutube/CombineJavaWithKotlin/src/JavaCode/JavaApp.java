package JavaCode;

import KotlinCode.myKotlinAddFUnctions;

public class JavaApp {
    public static void main(String[] args) {
        int sum = myKotlinAddFUnctions.add(5,4);
        System.out.println("get sum : " + sum);

        // java tidak menganut konsep default value
        int luasSegitiga = myKotlinAddFUnctions.luasSegitiga(4);
        System.out.println("luas segitiga1 : " + luasSegitiga);

        int luasSegitiga2 = myKotlinAddFUnctions.luasSegitiga(10);
        System.out.println("luas segitiga2 : " + luasSegitiga2);

    }
    public static int getArea(int a, int b){
        return a + b;
    }
}
