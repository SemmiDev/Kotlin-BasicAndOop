package Data

import Data.Costumer.Person

fun main() {
    var person1 = Person()

    print("Masukkan no antiran anda : " )
    val number= readLine()!!.toInt()
    print("Masukkan nama anda : ")
    val nama = readLine().toString()

    person1.namePerson(number,nama)
    person1.showPerson()
}

