package Data.Costumer

class Person {
    val namaPerson = hashMapOf<Int,String>()

    fun namePerson(number: Int, name: String){
        namaPerson.put(number, name)
    }

    fun showPerson(){
        for(i in namaPerson.keys){
            println("number $i : " + namaPerson[i])
        }
    }
}