fun main() {
    val nama = arrayOf("sammi","adit","ayatullah","gusnur","sammi","adit","adit","ayatullah","sammi","gusnur","sammi")
    // mencari ada berapa buah nama sammi
//    var sumSammi = 0
//    var sumAdit = 0
//    for(name in nama){
//        if(name == "sammi"){
//            sumSammi++
//        }else if(name == "adit"){
//            sumAdit++
//        }
//    }
//
//    println("jumlah nama sammi : " + sumSammi)
//    println("jumlah nama adit : " + sumAdit)
//
//    val result = sumSammi + sumAdit
//    println("jumlah dari nama sammi dan adit = " + result)

    // cara ringkas

    var sam = 0
    var adit = 0

    for(name in nama){
        when(name) {
            "sammi" -> sam = sam++
            "adit" -> adit = adit++
            else -> println("not")
        }
    }

    println("adit =  " + adit)
    println("sammi = " + sam)
    println("total = $sam$adit")


}