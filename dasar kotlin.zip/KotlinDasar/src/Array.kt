fun main() {
    var nama = Array<String>(5){""}
    for(index in 0..4){
        print("Masukkan nama : ")
        nama[index] = readLine()!!
    }

    for(index1 in 0..4){
        println("nama urutan ke $index1 : " + nama[index1])
    }
}