package Advanced2

class Constructor constructor(firstName: String){
    var firstName = ""
    class Constructor(firstName: String){

    }
    fun tampil(){
        println("your name is : " + this.firstName)
    }
}

fun main() {
    var a = Constructor("sam")
    a.tampil()
}