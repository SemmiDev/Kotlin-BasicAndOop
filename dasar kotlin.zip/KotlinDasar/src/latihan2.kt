fun main() {
    // inputan nama

    var orangIndonesia = arrayOf("naruto","sasuke","sakura")
    var orangJepang = arrayOf("faiz","blade","ryuki")
    var orangIndia = arrayOf("ayatullah","gusnur","dandi")
    var orangCina = arrayOf("adit","kawaki","rauf")

    var next = true
    while(next) {
        print("masukkan nama anda : ")
        var nama = readLine()

        when (nama) {
            in orangIndonesia -> {
                println("$nama orang indonesia")
                println("bukan orang bule")
            }
            in orangJepang -> {
                println("$nama orang jepang")
                println("orang bule")
            }

            in orangIndia -> {
                println("$nama orang india")
                println("orang gata")
            }

            in orangCina -> {
                println("$nama orang cina")
                println("orang hitam")
            }

            else -> println("orang sesat")
        }

        print("apakah anda ingin mengulang lagi (y/n) : ")
        var nextQuestion = readLine()
        if (nextQuestion == "y" || nextQuestion == "Y") {
            next = true
        } else if (nextQuestion == "n" || nextQuestion == "N") {
            next = false
        } else {
            println("piliihan anda salah")
            System.out
        }


//    if(nama in orangIndonesia){
//        println(nama + " -> bukan orang bule")
//    }else if(nama in orangJepang){
//        println(nama + " -> orang bule")
//    }else if(nama in orangIndia) {
//        println(nama + " -> orang hitam")
//    }else if(nama in orangCina){
//        println(nama + " -> orang mata sipit")
//    }else{
//        println("your name not undefined in our databases")
//    }
    }
}