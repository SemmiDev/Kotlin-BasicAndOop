package Class;

public class Classes {
    // membuat class diawali dengan keyword class kemudian diikuti dengan nama class nya
}
