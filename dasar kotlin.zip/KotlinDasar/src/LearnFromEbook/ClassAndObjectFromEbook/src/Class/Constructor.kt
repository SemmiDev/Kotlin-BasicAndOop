package Class



class InitOrderDemo(name: String){
    val firstProperty = "Fisrt property: $name"

    init{
        println("First initializer block thath prints ${name}")
    }

    val SecondProperty = "Second Propert: ${name.length}"

    init{
        println("SEcond intializer block that prints ${name.length}")
    }
}

class Customer(name: String){
    val customerKEy = name.toUpperCase()
}

class Person(val firstName: String, val lastName: String, var age: Int){
    val show = "your name is ${firstName} + ${lastName} + with age ${age}"
}

fun main() {
    InitOrder
}