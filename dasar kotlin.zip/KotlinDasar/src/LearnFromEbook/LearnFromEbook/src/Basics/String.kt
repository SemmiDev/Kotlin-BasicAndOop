package Basics

fun main() {
    var s = "sammi" + 1
    println(s + "def") // concat string using + operation

    s = "sammi"
    println("$s.length is  ${s.length}")

}