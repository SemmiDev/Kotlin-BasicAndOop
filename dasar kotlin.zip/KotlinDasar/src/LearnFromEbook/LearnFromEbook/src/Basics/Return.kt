package Basics

fun main() {
    fun foo(){
        listOf(1,2,3,4,5).forEach{
            if(it == 3){
                println(it)
            }
            println("this point is unreachable")
        }
    }

    fun foo2(){
        listOf(1,2,3,4,5).forEach lit@{
            if(it == 3) returnlit@
            println(it)
        }
        println("done with explisist code")
    }

    fun foo3() {
        listOf(1, 2, 3, 4, 5).forEach(fun(value: Int) {
            if (value == 3) return
            print(value)
        })
        print(" done with anonymous function")
    }
}