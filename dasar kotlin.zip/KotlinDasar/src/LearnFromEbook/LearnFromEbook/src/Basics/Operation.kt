package Basics

fun main() {
    fun print(a: Double): Double {
        return a
    }

    fun printt(){
        println("hello")
    }

    println(print(4.23432))
    printt()

}
