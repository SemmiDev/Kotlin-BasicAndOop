package Basics.controlFlow

fun main() {
//    var max = 10
//    var min = 5
//
//    if(max > min) println("$max > $min")
//    if(max.equals(10)) println("same") else println("not same")



//    var num = 5
//    var summ = if(num.equals(5)) "done" else "not done"
//    println(summ)

    print("input your name : ")
    val nama = readLine()
    val namaBase = listOf<String>("sam","eji")

    if(nama.equals(namaBase[0]) || nama.equals(namaBase[1])){
        println("done")
    } else{
        println("not")
    }

    val array = arrayOf("sam","amah")

    for ((index, value) in array.withIndex()) {
        println("the element at $index is $value")
    }




}