package Basics

fun main() {
    fun printDOuble(d: Double) {println(d)}
    var i = 2.3f
    var x = 5
    val y = 23.32932746323
    val r = 12.2

    printDOuble(i.toDouble())
    printDOuble(x.toDouble())
    printDOuble(y)
    printDOuble(r)
}