package BasicSintaks

fun main() {
//    val i = 0
//    val items = listOf<String>("sam","dev")
//
//    if(i in 0..1){
//        println(items[i])
//    }

//// check if a number is within a renge using in operator
//    val list = listOf<String>("a","b","c")
//    if(-1 !in 0..list.lastIndex){
//        println("-1 is out of range")
//    }
//
//    if(list.size !in list.indices){
//        println("list out is out of valid lisst indeces range too")
//    }

//// iterating
//    for(i in 0..10){
//        println(i)
//    }


//    // over a progression
//    for(x in 1..10 step 2) println(x) // jangkauan antara 2
//    for(x in 9 downTo 0 step 3) println(x) // mulai dari x sampai 0 dengan jarak 3 angka
//    for(i in 1 until 100) // jangkauan dari 2 sampai 99


    //// iterating for collections
//    val items = listOf<String>("apple","grape","orange")
//    when{
//        "orange"  in items -> println("orange")
//        "grape" in items -> println("grape")
//        "apple" in items -> println("apple")
//    }

    var nameMan = listOf("Abdul Rauf","Aditya Andika Putra","Aditya Fauzan NUl Haq","Ayatullah","Gusnur","Sammi")
    val nameWoman = listOf("Aulia Rahmah","Meli","Stefy")

    nameMan
        .filter { it.startsWith("a") || it.startsWith("A") }
        .sortedBy{it}
        .map { it.toLowerCase() }
        .forEach{println(it)}
    nameWoman
        .filter { it.startsWith("a") || it.startsWith("A") }
        .sortedBy { it }
        .map{it.toUpperCase()}
        .forEach{println(it)}

}