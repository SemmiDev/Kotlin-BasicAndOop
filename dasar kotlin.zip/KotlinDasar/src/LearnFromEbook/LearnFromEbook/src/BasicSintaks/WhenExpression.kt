package BasicSintaks

fun main() {
    print("insert your name : ")
    val insert = readLine()
    when(insert){
        "sam" -> println("sam")
        "dev" -> "dev"
    }
}