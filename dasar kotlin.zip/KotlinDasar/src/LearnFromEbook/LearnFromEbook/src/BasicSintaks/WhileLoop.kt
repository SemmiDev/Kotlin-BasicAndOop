package BasicSintaks

fun main() {
    val items = listOf<String>("banana","grape","watermelon")
    var index = 0

    while(index < items.size){
        println("item at $index is ${items[index]}")
        index++
    }
}