package BasicSintaks

fun main() {
    val items = listOf("apple","grape","watermelon")
    // cara pertama
    for(item in items){
        println(item)
    }
    // cara kedua
    for(index in items.indices){
        println("item at $index ${items[index]}")
    }
}