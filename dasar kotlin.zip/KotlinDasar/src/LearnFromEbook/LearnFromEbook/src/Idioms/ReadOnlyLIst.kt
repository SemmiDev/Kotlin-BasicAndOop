package Idioms

fun main() {
    val list = listOf("a","b","c")

}