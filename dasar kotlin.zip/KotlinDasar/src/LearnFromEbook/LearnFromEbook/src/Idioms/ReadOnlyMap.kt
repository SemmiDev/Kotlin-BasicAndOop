//package Idioms
//
//import sun.jvm.hotspot.oops.CellTypeState.value
//
//
//fun main() {
////    val map = mapOf("sam" to 1, "adit" to 2, "ayat" to 3)
////    // access
////    println(map["key"])
////    map["key"] = value
//}