// step pertama
//fun main() {
//    tesHello()
//
//}
//
//fun tesHello(){
//    println("Sammi Aldhiyanto")
//}



// step kedua
//fun main() {
//    var nama = "Sammi Aldhiyanto"
//    val umur = 17
//    println(nama)
//    println(umur)
//
//    nama = "Aditya" // kalau tipe data var bisa di assignment
//    val umurdua = 18 // kalau val tidak bisa
//}




// step ketiga
//fun main() {
//    val namaAwal = "Sam"
//    val namaAkhir = "Dev"
//
//    val result = namaAwal + namaAkhir
//    println("Nama anda    : " + result)
//    println("jumlah huruf : " + result.length)
//}



// step keempat
//fun main() {
//    val angka1 = "50"
//    val angka2 = 25
//
//    val result = angka1 + angka2 // penjumlahan dari string ke in tbisa, sebaliknya tidak bisa
//    println(result)
//
//
//    val angka3 = "24"
//    val angka4 = 12
//
//    val result2 = angka3.toInt() + angka4
//    println("jumlah : " + result2)
//
//    val name = "sam"
//    println(name[0])
//    println(name[1])
//    println(name[2])
//
//
//    // char
//    val char1 = 'a'
//
//}




// step kelima
//fun main() {
//    var names =  arrayOf("sam","dit","ayat")
//    names.toList()
//
//    println(names[0]) // ambil index ke 0
//    println(names.get(1)) // ambil index ke 1
//
//    names.set(2,"Dandi")
//    names.toList()
//
//    var angka = intArrayOf(1,2,3,4,5,6,7,8,9,10)
//    println(angka.max())
//    println(angka.min())
//
//    println(angka.first())
//    println(angka.last())
//
//    println(angka.count())
//
//}






// step keenam
//fun main() {
//
//    val test = true
//    println(test)
//
//    val a = 100
//    val b = 200
//    val c = a == b
//    println(c)
//
//    if(c == true){
//        println("benar, sama")
//    }else{
//        println("tidak sama")
//    }



//    val text = "sam"
//    val hasil = if(text == "sam"){
//        "same"
//    }else{
//        "not"
//    }
//
//    println(hasil)


//    var ket = ""
//    val teks = "sammi"
//
//    if(teks == "sammi"){
//        ket = "hai"
//    }else{
//        ket = "tidak hai"
//    }
//
//    println(ket)



//    val utang = 10000
//    val uang = 15000
//
//    if(uang > utang){
//        val result = uang - utang
//        println("lunas")
//        println("sisa uang anda : " + result)
//    }else if(uang < utang){
//        val result = utang - uang
//        println("uang anda tidak mencukupi untuk membayar hutang, uang anda berjumlah " + uang + " dan hutang berjumlah " + utang + ". maka sisa uang anda setelah utan diangsur : " + result)
//    }else if(uang == utang){
//        println("lunas")
//    }else{
//        println("undefined")
//    }
//
//
//}


//fun main() {
//    val ninja = arrayOf("naruto","sasuke","itachi")
//    val superhero = arrayOf("batman","superman","wonderwoman")
//    val kamenRider = arrayOf("Faiz","Kaiksa","Delta")
//
//    val karakter = "itachi"
//
//    if(karakter in ninja){
//        println("a ninja")
//    }else if(karakter in superhero){
//        println("a superhero")
//    }else{
//        println("a kamenrider")
//    }



//    val habitat = arrayOf("Air","Darat","AirDanDarat")
//    val hewan = arrayOf("kucing","ayam","katak","pasu","gurita")
//
//    println("1. kucing \n 2. ayam \n 3. katak \n 4. paus \n 5. gurita")
//
//    println("Masukkan  hewan pilihan anda : ")
//    val pilihan = readLine()
//    if(pilihan == hewan[0]){
//        println("hewan tersebut hidup di " + habitat[1])
//    }else if(pilihan == hewan[1]){
//        println("hewan tersebut hidup di " + habitat[1])
//    }else if(pilihan == hewan[2]){
//        println("hewan tersebut hidup di " + habitat[2])
//    }else if(pilihan == hewan[3]){
//        println("hewan tersebut hidup di " + habitat[0])
//    }else if(pilihan == hewan[4]){
//        println("hewan tersebut hidup di " + habitat[0])
//    }else{
//        println("inputan anda salah")
//    }


//
//    var angka1 = 10
//    var angka2 = 20
//
//    println("DATA ANDA : angka 1 : " + angka1 + " dan angka 2 : " + angka2)
//    println("masukkan operator anda")
//    val operation = readLine()
//
//    val result = if(operation == "+") angka1 + angka2
//                else if (operation == "-") angka1 - angka2
//                else if (operation == "*") angka1 * angka2
//                else angka1 / angka2
//
//    println("operasi yang dimasukkan adalah : " + operation + ", dan hasilnya : " + result)

//    val result = when(operation){
//        "+" -> angka1 + angka2
//        "-" -> angka1 - angka2
//        "*" -> angka1 * angka2
//        "/" -> angka1 / angka2
//        else -> println("uncomplete!!!")
//    }
//
//    println("hasil : " + result)



//}


//fun main() {
//    var i = 1
//    var l = 10
//
//    while(i <= 10){
//        println("angka : " + i)
//        i++
//    }
//
//    var result = 0;

//val nama = arrayOf("Sam","Adit A","Rauf","Adit F","Ayatuloh","Gusnur")
//
//for(i in 1..5) println("angka ke  $i")
//
//
//for(name in nama){
//    println("nama anda : $name")
//}

//}



//
//fun main() {
//    // arrays
//    val nama = arrayOf("Sam","Adit A","Rauf","Adit F","Ayatuloh","Gusnur", "Dandi")
//    // show
//    for(name in nama) println("nama anda : $name")
//
//
//
//    // for loop
//    var items = arrayOf("gold","silver","ZONK","ruby","ZONK","cik ayam")
//    for(item in items) {
//        if (item == "ZONK" || item == "cik ayam"){
//            continue
//            // continue berguna untuk, jika bertemu dengan zonk maka akan di skip dan akan masuk ke perulangan lagi, block code selanjutnya tidak di eksekusi
//        }
//        println("sedang menggali ...")
//        println("yes, kita mendapatkan : $item")
//    }
//
//
//}

fun main() {
    // looping ringkas

    var largeValue = max(4,5)
    println(largeValue)
    fun max(Int: value1 , Int: value2): Int = if(value1 > value2) a else b
    }
}


















