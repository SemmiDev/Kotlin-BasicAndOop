package Advanced3

fun main() {
    print("input your firstname : ")
    var firstNameInput = readLine()


    var person1 = Person()
    person1.lastName = "Dev"

    if (firstNameInput != null) {
        person1.namePerson(firstNameInput)
    }

    println("you age age is : $person1.umur") // if we no put the age in the kurawal tag, so will show reference from that var
    println("you age age is : ${person1.umur}") // look the different

}
class Person {
    var lastName:String = ""
    var kelas:Int = 12

    var umur: Int = 0


    fun namePerson(firstName: String) {
        println("you name is : " + firstName + lastName)
        println("now, you are class " + kelas)


    }

}