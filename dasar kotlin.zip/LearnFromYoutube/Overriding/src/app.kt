fun main(args: Array<String>) {
    var cat = Cat()
    println(cat.color)
    println(cat.age)
    cat.eat()

    var dog = Dog()
    println(dog.color)
    dog.breek()
    dog.eat()
}

open class Animal{
    open var color: String = "white"
    open fun eat(){ // untuk mengoverride func ini maka harus ditambahkan keyword open di depannya
        println("eating")
    }
}

class Cat : Animal(){
    var age: Int = 15
    override var color: String = "blue"
    override fun eat() {
        super.eat() // akan menampilkan yg ada di kls animal
        println("eating herbivora")
    }

}

class Dog: Animal() {
    fun breek() {
        println("yes")
    }

    override var color: String = "brown"

    override fun eat() {
        super.eat()
        println("eating karnivora")
    }
}