package com.belajar

fun main(args: Array<String>) {
    val program2 = Program2()

//    val lamb : (Int,Int) -> Int =  {x:Int, y: Int -> x + y}
//    val lamb : (Int,Int) -> Int =  {x,y -> x + y}

    program2.add(2,7,{x,y -> x + y}) // sama saja
    program2.add(2,7) {x,y -> x + y} // sama saja
}

class Program2{
    fun add(a: Int,b: Int,action: (Int,Int) -> Int){
        var res = action(a,b)
        println(res)
    }
}