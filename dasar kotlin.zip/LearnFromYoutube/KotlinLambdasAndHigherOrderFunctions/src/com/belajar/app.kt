package com.belajar

fun main(args: Array<String>) {
    val program = Program()
    program.addTwoNumber(5,3)
    program.addTwoNumber(3,4,object : MyInterfacae{
        override fun execute(sum: Int) {
            println(sum)
        }
    })

    // lambda
    val test: String = "hello"
    val myLambda: (Int) -> Unit = {s: Int -> println(s)} // lambda expressions
    program.addTwoNumber(3,2,myLambda)
}

class Program{

    fun addTwoNumber(a: Int,b: Int, action: (Int) -> Unit){ // high level  functions
        val sum = a + b
        action(sum) // println(s)
    }

    fun addTwoNumber(a: Int,b: Int){ // normal funt
        val sum = a + b
        println(sum)
    }

    fun addTwoNumber(a: Int,b: Int,action: MyInterfacae){ // interface func
        val sum = a + b
        println(sum)
        action.execute(sum)
    }
}

interface MyInterfacae{
    fun execute(sum: Int)
}