import java.math.BigInteger

fun main(args: Array<String>) {
    println(getFibonacciNUmber(1000, BigInteger("1"), BigInteger("0")))
}

// dengan menggunakna keywork tailrec, berapapun angkanya akan ditampilkan
// kalau tidak pakai itu akan error stack over flow, tidak cukup memori
tailrec fun getFibonacciNUmber(n: Int, a: BigInteger, b: BigInteger): BigInteger{
    if(n == 0)
        return b
    else
        return getFibonacciNUmber(n - 1, a + b, a)
}