package belajar


fun main(args: Array<String>) {
    // rekursif artinya dia memanggil fungzinya sendiri
    val angka: Int = 20
    val result = factorial(angka)
    println("Hasilnya adalah $result")
    }

fun factorial(num: Int): Int{
   return if(num == 1) num
          else num * factorial(num - 1)
}