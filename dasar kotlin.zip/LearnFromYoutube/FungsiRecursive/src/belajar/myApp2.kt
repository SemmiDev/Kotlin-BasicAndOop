package belajar

fun main(args: Array<String>) {

    print("Masukkan untuk n : ")
    var choicePermnN = readLine()!!.toInt()
    print("Masukkan untuk c / n : ")
    var choicePermC = readLine()!!.toInt()

    print("Masukkan metode (permutasi / kombinasi) : ")
    var insertChoice = readLine()

    if(insertChoice.equals("permutasi")) println("hasil permutasinya : " + permutasi(choicePermnN,choicePermC))
    else if(insertChoice.equals("kombinasi")) println("hasil permutasinya : " + kombinasi(choicePermnN,choicePermC))
    else System.exit(0)
}

fun rekursif(num: Int): Int{
    return if(num == 1) num
        else num * rekursif(num - 1)
}

fun permutasi(nilaiN: Int, nilaiP: Int): Int{
    var temporary = nilaiN - nilaiP
    var permResult = rekursif(nilaiN) / rekursif(temporary)
    return permResult
}

fun kombinasi(nilaiN: Int, nilaiC: Int): Int{
    var temp = nilaiN - nilaiC
    var fakT = factorial(temp)
    var fakC = factorial(nilaiC)
    var tempR = fakT * fakC
    var komResult = factorial(nilaiN) / tempR
    return komResult
}