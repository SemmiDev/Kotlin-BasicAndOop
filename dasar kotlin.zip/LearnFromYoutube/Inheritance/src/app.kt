fun main(args: Array<String>) {

    var dog = Dog()
    dog.bark()
    dog.color = "black"
    dog.breed = "breed"
    dog.eat()

    var cat = Cat()
    cat.eat()
    cat.color = "blue"
    cat.age = 12

    var animal = Animal()
    animal.eat()
    animal.color = "yellow"

}

open class Animal{
    var color:String = "white"
    fun eat(){
        println("eat")
    }
}

class Cat : Animal(){
    var age :Int = 0
}

class Dog : Animal(){
    var breed:String = ""
    fun bark(){
        println("Bark")
    }
}