package Belajar

fun main(args: Array<String>) {
    var student = Student()
    println(student.hasPassed(87))

    println(student.isSchoolar(90))
}

fun Student.isSchoolar(marks: Int): Boolean{
    return  marks > 89
}

class Student{
    fun hasPassed(marks: Int): Boolean{
        return marks > 75
    }
}
