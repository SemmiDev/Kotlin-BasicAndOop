package Belajar

fun main(args: Array<String>) {
    val angka1 = 10
    val angka2 = 13

    println(angka1.greaterValue(angka2))
}

fun Int.greaterValue(other: Int): Int {
    if(this > other) return this
    else return other
}