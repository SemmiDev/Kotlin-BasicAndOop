fun main(args: Array<String>) {
    var student = Student("Sam",1)
    println(" index number : ${student.id}")
}

class Student(var name: String){
    var id: Int = -1

    init{
        println("Student has got a name as : $name")
    }
    // secondary constructor
    constructor(n: String, id: Int): this(n){
        this.id = id
    }
}