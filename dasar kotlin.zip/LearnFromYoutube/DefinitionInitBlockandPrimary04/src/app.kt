fun main() {
    var name = Student("Sam")
}

// class yg berisi parameter itu artinya adalah constructor
class Student(var name: String){
//    var name: String = "anonymous"

    // init berguna untuk constructor hehew
    init{
        println("Student has got a name as : ${name}")
    }
}