fun main(args: Array<String>) {
    var user1 = User("Sam",1)
    var user2 = User("Sam",1)

    var user3 = User2("Sam",1)
    var user4 = User2("Sam",1)



    // hasilnya akan not equal
    // jika kita menambahkan keyword data sebelum class User, maka akan equal
    // data artinya isi,valuenya yg akan dibandingkan bukan objek nya

    if(user1 == user2) println("equal")
    else println("not equal")

    if(user3 == user4) println("equal")
    else println("not equal")


    // kita bisa test
    println(user1) // tanpa keyword data dia akan menampilkan reference memorynya, kalau tidak maka akan tampil valuenya
    println(user1.toString())

    // kita bisa mengcopy nya
    var newUser = user1.copy()
    println(newUser)
    // ubah isi parameter juga bisa
    newUser = user1.copy(name = "Peter", id = 2)
    println(newUser)



}

data class User(var name:String, var id:Int){} // kalau menggunakan 'data' parameter nya harus pakai var atau val

class User2(var name:String, var id:Int){}