fun main(args: Array<String>) {
 var myBtn = MyButton()
    myBtn.onClick()
    myBtn.onTouch()
    myBtn.onHover()
}

// interface not a class
// contains abstract and normal method
interface MyInterfaceListener{

    // di interface apapun akan abstract secara default
    // class interface tidak bisa di instance

    // var name:String
    // jika kita pakai keyword abstrat kita tidak boleh pakai kurung kurawal
    fun onTouch(){
        println("my first touch interface")
    }
    fun onClick(){
        println("my first click interface")
    }
}

interface mySecondInterface {
    // normal method
    fun onTouch(){
        println("my second touch interface")
    }
    fun onClick(){
        println("my second click interface")
    }
    fun onHover(){
        println("my second hover interface")
    }
}

// bisa pakai 2 interface
class MyButton: MyInterfaceListener, mySecondInterface{
        override fun onTouch() {
        println("my touch myButton from interface 1")
    }
    override fun onClick() {
        // akan error jika tidak kita beri <nama interface> karena interface 1 dan 2 sama methodnya
        // kita harus beri penanda
        super<mySecondInterface>.onClick()
        super<MyInterfaceListener>.onClick() // kita juga bisa panggil ini method
    }
    override fun onHover() {
        super.onHover()
    }



}