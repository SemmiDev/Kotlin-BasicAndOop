package com.belajar

fun main(args: Array<String>) {
    Person.name = "Sammi"
    println(Person.name)
    Person.sayHello()
}

class Person{
    companion object{
        var name:String = "Sam"
        fun sayHello(){
            println("Hello " + name)
        }
    }
}