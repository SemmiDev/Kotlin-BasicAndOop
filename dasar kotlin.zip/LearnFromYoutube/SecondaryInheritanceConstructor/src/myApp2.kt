fun main(args: Array<String>) {
     Dog("balck","yes")

}

open class Animal{
    var color:String = ""

    constructor(color:String){
        this.color = color
        println("the color from animal is : $color")
    }
}

class Dog: Animal{
    var breed:String = ""

    constructor(color:String, breed:String): super(color){
        this.breed = breed

        println("the breed from dog is : ${breed}")
    }
}