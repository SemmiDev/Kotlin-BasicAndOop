//fun main(args: Array<String>) {
//    Dog("Black","yes")
//
//}
//
//open class Animal(var color: String) { // seper class
//    init{
//        println("from animal init color : $color")
//    }
//}
//// primary parameter                        // secondary
//class Dog(color:String, var breed:String): Animal(color){ // deriver class
//         init {
//             println("from dog init : $color and $breed")
//         }
//}