package com.belajar

fun main(args: Array<String>) {

    println(Customer.id)
    Customer.registerCustomer()

    Customer.id = "Sammidev"
    println(Customer.id)

    Customer.myMethod("hello")

}

open class MySuperClass{
    open fun myMethod(str: String){
        println("muSuperClass")
    }
}

// kalau tipe objek kita tidak perlu menn insatance kaan nya, ibarat static di java
object Customer : MySuperClass(){
    var id:String = "Sam"
    fun registerCustomer(){
        println("done!")
    }
    override fun myMethod(str:String){
        super.myMethod(str)
        println("objec customer data : " + str)
    }

    // jangan lupa init adalah yg pertama kali dijalanlan
    init {
        println("ai")
    }
}