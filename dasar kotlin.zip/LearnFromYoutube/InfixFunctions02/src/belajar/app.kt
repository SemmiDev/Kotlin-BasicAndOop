package belajar

fun main(args: Array<String>){
    val angka1: Int = 10
    val angka2: Int = 7

    val greatesVal = angka2 greaterValue angka1 // kita tidak perlu tanda titik, cukup spasi
    println("the greatervalue is : " + greatesVal)



}

// infix func and also exten func
// infix hanya untuk menerima satu parameters
infix fun Int.greaterValue(other: Int): Int{
    if(this > other) return this
    else return other
}