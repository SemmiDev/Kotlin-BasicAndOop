fun main(args: Array<String>) {
    var money = 1000000
    var buy = product(arrayOf("monitor","keyboard","mouse"))
    pay(money,buy)
}

fun product(items: Array<String>): Int{
    var totalBelanja = 0
    for(item in items){
        when(item){
            "keyboard" -> totalBelanja += 5000
            "mouse"    -> totalBelanja += 5000
            "monitor"  -> totalBelanja += 500000
            else -> totalBelanja += 0
        }
    }
    return totalBelanja
}

fun pay(money: Int, totalBelanja: Int){
    if(money >= totalBelanja){
        var totalBiaya = money - totalBelanja
        println(" total belanja kamu : $totalBelanja\n uang yg kamu miliki : $money\n sisa uang kamu : $totalBiaya")
    }else{
        println("uang kamu tidak cukup")
    }
}


