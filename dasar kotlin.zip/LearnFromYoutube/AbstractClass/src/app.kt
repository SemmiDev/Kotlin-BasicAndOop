fun main(args: Array<String>) {

}

abstract class Person{

    // pada abstract var ataupun function, tidak diperbolehkan mengisialisasi sesuatu, harus blank
    // pada sebuah method abstract tidak boleh gunakan kurung kurawal, cukup sampai dengan ()
    // untuk abstract dia akan otomatis open, dan class nya harus abstract juga
    abstract fun eat()
    abstract var nama2:String

    // open bisa di override
    open var nama: String = "sam"
    open fun getHeight(){}

    // tidak bisa di ovveride
    fun gotoSchool(){}
}

class Indonesian: Person(){
    override var nama: String = "samdev"
    // kita akan dipaksa untuk meimplement method yg ada di class abstract person
    override fun eat() {
        println("eat")
    }

    // ini wajib di override karna abstract var
    override var nama2: String = "sammi aldhiyanto"

    // class person harus dibuat open, agar tidak final, dan bisa di overriding
    override fun getHeight() {
        println("height")
    }
}
