fun main(args: Array<String>) {
    var oppoA100 = SmartphoneOppo()
    println("OPPO A100")
    println(oppoA100.chipType)
    println(oppoA100.ramCapacity)
    println(oppoA100.totalingCameraRes)
    println(oppoA100.batteryCap)
    println(oppoA100.layerSize)

    oppoA100.supportNetwork()
}

abstract class Spek{
    abstract var chipType: String
    abstract var ramCapacity: Int
    abstract var totalingCameraRes: Float
    abstract var batteryCap: Int
    abstract var layerSize: Float
    abstract var supportNet: Array<String>
}

class SmartphoneOppo: Spek() {

    override var chipType: String = "Snapdragon 865+"
    override var ramCapacity: Int = 12
    override var totalingCameraRes: Float = 198.2F
    override var batteryCap: Int = 6000
    override var layerSize: Float = 6.2F
    override var supportNet: Array<String> = arrayOf("2G","3G","4G","5G")

    fun supportNetwork(){
        for(item in supportNet){
            println(item)
        }
    }
}